-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 15, 2020 at 05:46 AM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `admin_id` int(100) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `admin_image` text NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_country` text NOT NULL,
  `admin_job` varchar(255) NOT NULL,
  `admin_about` text NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_image`, `admin_contact`, `admin_country`, `admin_job`, `admin_about`) VALUES
(1, 'Geetik Nimonkar', '2019063@iiitdmj.ac.in', 'password', 'geetik.jpg', '7869600871', '', 'Student', '  DBMS Student'),
(2, 'Gaurang Verma', '2019061@iiitdmj.ac.in', 'password', '', '', '', '', ''),
(3, 'Shivam Gupta', '2019337@iiitdmj.ac.in', 'password', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `p_id` int(100) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `qty` int(100) NOT NULL,
  `size` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`p_id`, `ip_add`, `qty`, `size`) VALUES
(14, '47.247.151.185', 1, 'Select a size'),
(6, '47.247.105.90', 3, 'Medium'),
(28, '47.247.55.88', 1, 'Medium'),
(28, '149.129.145.91', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int(100) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_pass` varchar(255) NOT NULL,
  `customer_country` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_image` text NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `customer_address`, `customer_image`) VALUES
(19, 'Shivam Gupta', '2019337@iiitdmj.ac.in', 'password', 'India', 'Varanasi', '8945671230', '45 M.G. Road , Varanasi (U.P.)', 'shivam.jpg'),
(18, 'Gaurang Verma', '2019061@iiitdmj.ac.in', 'password', 'India', 'Kanpur', '7896541230', '23 Civil Lines, Kanpur (U.P.)', 'gaurang.jpg'),
(17, 'Geetik', 'geetiknimonkar@gmail.com', 'password', 'India', 'Dewas', '7869600873', '21 Colony Bagh Dewas (M.P.)', 'geetik.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

DROP TABLE IF EXISTS `customer_order`;
CREATE TABLE IF NOT EXISTS `customer_order` (
  `order_id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) NOT NULL,
  `product_id` int(100) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `order_status` text NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`order_id`, `customer_id`, `product_id`, `due_amount`, `invoice_no`, `qty`, `order_date`, `order_status`) VALUES
(36, 17, 4, 46, 1663667712, 2, '2020-12-13 12:06:13', 'pending'),
(35, 17, 6, 50, 846553825, 2, '2020-12-13 11:02:03', 'pending'),
(34, 17, 14, 90, 1857722557, 1, '2020-12-13 09:14:35', 'pending'),
(33, 18, 28, 80, 1964157881, 2, '2020-12-13 09:06:15', 'pending'),
(32, 17, 8, 140, 1835138878, 5, '2020-12-13 08:56:45', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int(10) NOT NULL,
  `invoice_id` int(100) NOT NULL,
  `amount` int(100) NOT NULL,
  `payment_mode` text NOT NULL,
  `ref_no` int(100) NOT NULL,
  `payment_date` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(10) NOT NULL AUTO_INCREMENT,
  `p_cat_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `product_title` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `cat_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_desc`, `product_keywords`) VALUES
(4, 1, 8, '2020-12-12 20:02:07', 'Wheat', '1p2.jpg', '1p3.jpg', '1p1.jpg', 23, '', 'wheat'),
(39, 4, 8, '2020-12-12 21:25:34', 'Cauliflower', '26p2.jpg', '26p3.jpg', '26p1.jpg', 30, 'vegetable', 'vegetable'),
(5, 1, 8, '2020-12-12 20:07:17', 'Rice', '2p2.jpg', '2p1.jpg', '2p3.jpg', 50, '', 'rice'),
(6, 1, 8, '2020-12-12 20:08:33', 'Barley', '3p2.jpg', '3p1.jpg', '3p3.jpg', 25, '', 'grain'),
(7, 1, 8, '2020-12-12 20:12:43', 'Maize', '4p1.jpg', '4p3.jpg', '4p2.jpg', 30, '', 'maize'),
(8, 1, 8, '2020-12-12 20:13:21', 'Millet', '5p1.jpg', '5p2.jpg', '5p3.jpg', 28, '', 'grain'),
(9, 2, 8, '2020-12-12 21:54:46', 'Arhar', '6p1.png', '6p2.png', '6p3.jpg', 65, '', 'puise'),
(38, 4, 8, '2020-12-12 21:24:34', 'Cabbage', '25p3.jpg', '25p2.jpg', '25p1.jpg', 40, 'vegetable', 'vegetable'),
(10, 2, 8, '2020-12-12 20:21:45', 'Moong', '7p3.jpg', '7p2.jpg', '7p1.jpg', 70, '', 'pulse'),
(11, 2, 8, '2020-12-12 20:22:30', 'Masoor', '8p3.jpg', '8p2.jpg', '8p1.jpg', 67, '', 'pulse'),
(12, 2, 8, '2020-12-12 20:23:13', 'Chana', '9p2.jpg', '9p1.jpg', '9p3.jpg', 80, '', 'pulse'),
(13, 2, 8, '2020-12-12 20:23:49', 'Rajma', '10p1.jpg', '10p3.jpg', '10p2.jpg', 140, '', 'pulse'),
(14, 3, 8, '2020-12-12 20:40:13', 'Apple', '11p3.jpg', '11p2.jpg', '11p1.jpeg', 90, '', 'fruit'),
(15, 3, 8, '2020-12-12 20:41:51', 'Mango', '12p1.jpg', '12p3.jpg', '12p2.jpg', 60, '', 'fruit'),
(17, 3, 8, '2020-12-12 20:42:35', 'Banana', '13p1.jpg', '13p3.jpeg', '13p2.jpg', 40, '', 'fruit'),
(18, 3, 8, '2020-12-12 20:43:24', 'Guava', '14p1.jpg', '14p2.jpg', '14p3.jpg', 30, '', 'fruit'),
(19, 3, 8, '2020-12-12 20:44:14', 'Orange', '15p1.jpg', '15p3.jpg', '15p2.jpg', 85, '', 'fruit'),
(20, 3, 8, '2020-12-12 20:45:19', 'White Grape', '16p3.jpg', '16p2.jpg', '16p1.jpg', 100, '', 'fruit'),
(21, 3, 8, '2020-12-13 06:23:15', 'Black Grape', '17p3.jpg', '17p2.jpg', '17p1.jpg', 120, '', 'fruit'),
(23, 3, 8, '2020-12-12 20:46:56', 'Pineapple', '18p3.jpg', '18p2.jpg', '18p1.jpg', 60, '', 'fruit'),
(24, 3, 8, '2020-12-12 20:47:40', 'Lichi', '19p3.jpg', '19p1.jpg', '19p2.jpg', 80, '', 'fruit'),
(25, 3, 8, '2020-12-12 20:48:21', 'Dragon Fruit', '20p1.jpg', '20p2.jpg', '20p3.jpg', 70, '', 'fruit'),
(26, 4, 8, '2020-12-12 21:19:53', 'Potato', '21p1.jpg', '21p3.jpg', '21p2.jpg', 35, '', 'vegetable'),
(28, 4, 8, '2020-12-12 21:20:36', 'Onion', '22p3.jpg', '22p1.jpeg', '22p2.jpg', 40, '', 'vegetable'),
(37, 4, 8, '2020-12-12 21:23:35', 'Spinach', '24p2.jpg', '24p3.jpg', '24p1.jpg', 30, 'sa', 'vegetable'),
(29, 4, 8, '2020-12-12 21:21:23', 'Tomato', '23p1.jpg', '23p2.jpeg', '23p3.jpg', 60, '', 'vegetable'),
(40, 4, 8, '2020-12-12 21:26:21', 'Pea', '27p3.jpg', '27p1.jpg', '27p2.jpg', 60, 'vegetable', 'vegetable'),
(41, 4, 8, '2020-12-12 21:27:01', 'Lady Finger', '28p2.jpg', '28p3.jpg', '28p1.jpg', 30, 'vegetable', 'vegetable'),
(42, 5, 8, '2020-12-12 21:38:46', 'Rangoon', '29p3.jpg', '29p1.jpg', '29p2.jpg', 500, 'flower', 'flower'),
(43, 5, 8, '2020-12-12 21:39:42', 'Rose', '30p3.jpg', '30p1.jpg', '30p2.jpeg', 450, 'flower', 'flower'),
(44, 5, 8, '2020-12-12 21:40:22', 'Jasmine', '31p1.jpg', '31p2.jpg', '31p3.jpg', 450, 'flower', 'flower'),
(45, 5, 8, '2020-12-12 21:41:05', 'Passion', '32p2.jpg', '32p1.jpg', '32p3.jpg', 500, 'flower\r\n', 'flower'),
(46, 5, 8, '2020-12-12 21:41:49', 'Lily', '33p2.jpg', '33p3.jpg', '33p1.jpg', 400, 'flower', 'flower'),
(47, 5, 8, '2020-12-12 21:42:38', 'Jasmine Rose', '34p1.jpg', '34p2.jpg', '34p3.jpg', 550, 'flower', 'flower'),
(48, 5, 8, '2020-12-12 21:43:26', 'Hibiscus', '35p2.jpg', '35p3.jpg', '35p1.jpg', 400, 'flower', 'flower'),
(49, 5, 8, '2020-12-12 21:44:13', 'Gul Mohar', '36p1.jpg', '36p2.jpg', '36p3.jpg', 300, 'flower', 'flower'),
(50, 5, 8, '2020-12-12 21:44:55', 'Lotus', '37p3.jpg', '37p2.jpg', '37p1.jpg', 400, 'flower', 'flower'),
(51, 5, 8, '2020-12-12 21:45:36', 'Marigold', '38p3.jpg', '38p1.jpg', '38p2.jpg', 350, 'flower', 'flower'),
(52, 5, 8, '2020-12-12 21:47:03', 'Sunflower', '39p1.jpg', '39p2.jpg', '39p3.jpg', 350, 'flower', 'flower'),
(53, 5, 8, '2020-12-12 21:47:39', 'Petunia', '40p1.jpg', '40p2.jpg', '40p3.jpg', 400, 'flower', 'flower');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
CREATE TABLE IF NOT EXISTS `product_categories` (
  `p_cat_id` int(10) NOT NULL AUTO_INCREMENT,
  `p_cat_title` text NOT NULL,
  `p_cat_desc` text NOT NULL,
  PRIMARY KEY (`p_cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`p_cat_id`, `p_cat_title`, `p_cat_desc`) VALUES
(1, 'Grains', ''),
(2, 'Pulses', ''),
(3, 'Fruits', ''),
(4, 'Vegetables', ''),
(5, 'Flowers', '');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE IF NOT EXISTS `slider` (
  `slider_id` int(10) NOT NULL AUTO_INCREMENT,
  `slider_name` varchar(255) NOT NULL,
  `slider_image` text NOT NULL,
  PRIMARY KEY (`slider_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slider_id`, `slider_name`, `slider_image`) VALUES
(1, 'slider number 1', '1p.jpg'),
(2, 'slider number 2', '2p.jpg'),
(3, 'slider number 3', '3p1.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
